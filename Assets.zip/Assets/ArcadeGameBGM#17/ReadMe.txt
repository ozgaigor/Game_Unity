Arcade Game BGM #17

music concept : Arcade Game, Casual Game, Retro Game, Sci-Fi

Loop Seamlessly.

-----Contents-----

ArcadeGameBGM#17.wav / Loop/ 00:15 / BPM 120 / 48kHz, 16Bit


E-mail : 4crain@gmail.com